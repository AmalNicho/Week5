package week5.day2.Assignmentfinal;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Dynamicdata {

	public static String[][] reads(String sheetname) throws IOException {

		XSSFWorkbook excel = new XSSFWorkbook("./TestData/AllDetails.xlsx");
		XSSFSheet sheet = excel.getSheet(sheetname);
		int lastRowNum = sheet.getLastRowNum();
		XSSFRow row = sheet.getRow(0);
		short lastCellNum = row.getLastCellNum();
		String[][] fvalue = new String[lastRowNum][lastCellNum];

		for (int i = 1; i <= lastRowNum; i++) {
			XSSFRow row2 = sheet.getRow(i);
			for (int j = 0; j < lastCellNum; j++) {

				XSSFCell cell = row2.getCell(j);
				String value = cell.getStringCellValue();
				fvalue[i - 1][j] = value;
			}

		}
		excel.close();
		return fvalue;

	}

}
