package week5day2.Assignments;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
public class CreateLead extends CommonQuery{
	
	@Test(dataProvider="CreateDataLead",priority=1) 
	public void learnCreateLead(String UserName,String Password,String CompanyName,String FullName,String LastName) {
		driver.findElement(By.id("username")).sendKeys(UserName);
		driver.findElement(By.id("password")).sendKeys(Password);
		driver.findElement(By.className("decorativeSubmit")).click();
		driver.findElement(By.linkText("CRM/SFA")).click();
		driver.findElement(By.linkText("Leads")).click();
		driver.findElement(By.linkText("Create Lead")).click();
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(CompanyName);
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(FullName);
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(LastName);
		driver.findElement(By.name("submitButton")).click();
		
}
	@DataProvider 
	public String[][] CreateDataLead() throws IOException {
		String[][] x = testcase.testvalue("CreateLead");
		return x;
	}
}


 


	
